#include "pch.h"

void PrintText() {
	auto a = "Hellow world";
}